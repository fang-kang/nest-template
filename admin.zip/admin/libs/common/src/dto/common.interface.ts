/* eslint-disable prettier/prettier */
export class BaseInterface {
  id: number;
  created_time: Date;
  updated_time: Date;
}
